/* dummy file for autoconf */
