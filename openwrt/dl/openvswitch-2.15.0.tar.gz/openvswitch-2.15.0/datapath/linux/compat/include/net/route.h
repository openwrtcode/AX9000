#ifndef __NET_ROUTE_H_WRAPPER
#define __NET_ROUTE_H_WRAPPER

#include_next <net/route.h>

#endif
