#pragma once

#define CPY_TEST_STR_2 "Hello "
