void tmp_func(void) {
    fprintf(stdout, "This is a function that fails if stdio is not #included.\n");
}

int cfunc(void) {
    return 0;
}
