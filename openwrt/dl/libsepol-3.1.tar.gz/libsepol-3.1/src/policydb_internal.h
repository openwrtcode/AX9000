#ifndef _SEPOL_POLICYDB_INTERNAL_H_
#define _SEPOL_POLICYDB_INTERNAL_H_

#include <sepol/policydb.h>

extern const char *policydb_target_strings[];
#endif
